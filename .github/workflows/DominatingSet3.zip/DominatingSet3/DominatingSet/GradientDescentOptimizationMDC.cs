﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DominatingSet
{
    class GradientDescentOptimizationMDC
    {
        int[,] adjacencyMatrix;

        int N;

        double[] X;

        const double factor = 1.1;

        List<List<int>> adjacencyList = null;

        int nEdge = 0;

        void Matrix2AdjacencyList(int[,] graph)
        {

             N = graph.GetLength(1);

            nEdge = 0;

            adjacencyMatrix = graph;

            for (int i = 0; i < N; i++) adjacencyMatrix[i, i] = 1;


            adjacencyList = new List<List<int>>();

            for(int i=0; i<N; i++)
            {
                List<int> list = new List<int>();

                for(int j=0; j<N; j++)
                {
                    if (adjacencyMatrix[i, j] == 1) list.Add(j);
                }

                adjacencyList.Add(list);

                nEdge += list.Count - 1;
            }
        }



        double max_neighbour(int i)
        {

            double max = 0;

            List<int> neighbours = adjacencyList[i];

            for (int j = 0; j < neighbours.Count; j++)
            {
                if (max <  X[neighbours[j]]) max = X[neighbours[j]];               
            }
            return max;
        }

        void DerivativeXi(int i )
        {

            List<int> neighbours = adjacencyList[i];

            double gxi = gx[i];

            for (int j = 0; j < neighbours.Count; j++)
            {
                if ( X[neighbours[j]]== gxi) derivativeX[neighbours[j]] +=1.1;
            }

           // if (gxi != X[i])
                derivativeX[i] += -1;
        }


                     
        double[] gx;

        double Function_T_Value( )
        {

            double sum = 0;

            for (int k = 0; k < N; k++)
            {
                gx[k] = max_neighbour(k);

                sum += factor*gx[k] - X[k];
            }

            return sum;
        }

        double[] derivativeX;

        double[] ComputeDerivativeX()
        {

            for (int i = 0; i < N; i++) derivativeX[i] = 0;
            for (int i = 0; i < N; i++) DerivativeXi(i);

            for (int i = 0; i < N; i++)
            {                
                if ((Math.Abs(derivativeX[i]) < 0.1) && (X[i] > 0.15) && (X[i] < 0.85))
                    if (rand.NextDouble() < 0.5)
                        derivativeX[i] = 1;
                   else
                        derivativeX[i] = -1;

            }

            return derivativeX;
        }



        void CopyDoubleArray(double[] dstArray, double[] srcArray)
        {
            int len = dstArray.Length;

            for (int i = 0; i < len; i++) dstArray[i] = srcArray[i];
        }

        //-------------------------------------------------------------------------------


        Random rand = new Random();

        bool bInialize = false;

        int[] probabilitySpan;
        
        void InitializeX2()
        {

           

            if(!bInialize)
            {
                bInialize = true;

                probabilitySpan = new int[N + 1];

                probabilitySpan[0] = 0;

                for (int i = 0; i < N; i++)
                    probabilitySpan[i + 1] = probabilitySpan[i] + adjacencyList[i].Count;
            }


            double avgEdge = nEdge * 1.0 / N + 1;

            int totalSpan = probabilitySpan[N];

            int n = rand.Next(N);

            for (int i = 0; i < n; i++)
            {
                int p = rand.Next(totalSpan);

                int start = (int)(p / avgEdge);

                int k = 0;

                if (probabilitySpan[start] > p)
                {
                    while (probabilitySpan[start] > p)
                    {
                        start -= 10;
                        if (start < 0)
                        {
                            start = 0;
                            break;
                        }
                    }

                    for (k = start; k <= N; k++)
                        if (probabilitySpan[k] > p) break;
                }
                else if(probabilitySpan[start] <= p)
                {
                    while (probabilitySpan[start]< p)
                    {
                        start += 10;
                        if (start >N)
                        {
                            start = N;
                            break;
                        }
                    }
                    for (k = Math.Max(0,start-10); k <= N; k++)                    
                        if (probabilitySpan[k] > p) break;
                }

                X[k-1] = rand.NextDouble()*0.5 * (adjacencyList[k-1].Count / avgEdge);
            }
        }


        void InitializeX()
        {
            double avgEdge = nEdge * 1.0 / N + 1;

            int count = (int)(N / avgEdge);

            for (int i = 0; i < count; i++)
            {
                int k = rand.Next(N);
                X[k] = rand.NextDouble(); // * 0.5 * (adjacencyList[i].Count / avgEdge);
            }
        }

        double[] originalX;
        double bestY = 0;
        double GetOneSolution()
        {

            

            InitializeX();                 

            int noChangeCount = 0;

            const double noiseWave = 0.001;

            for (int n = 0; n < 100; n++)
            {               

                double Y = Function_T_Value();

                ComputeDerivativeX();

                CopyDoubleArray(originalX, X);                

                //-----------------------search the best step------------------------------
                bestY = Y;

                int bestStepCount = 0;

                double step = 0.02;

                for (int stepCount = 1; stepCount <= 64; stepCount *= 2)
                {
                    
                    for (int j = 0; j < N; j++)
                    {
                        X[j] = originalX[j] + derivativeX[j] * stepCount * step;

                        //X[j] += (rand.NextDouble() - 0.5) * 0.01;

                        if (X[j] < 0) X[j] = rand.NextDouble() * noiseWave;
                        if (X[j] > 1) X[j] = 1 - rand.NextDouble() * noiseWave;                        
                    }

                    Y = Function_T_Value();

                    if (Y > bestY)
                    {
                        bestY = Y;

                        bestStepCount = stepCount;
                    }
                    else
                    {
                        break;
                    }
                }

                //-------------------------------------------------

                for (int j = 0; j < N; j++)
                {
                    X[j] = originalX[j] + derivativeX[j] * bestStepCount * step;

                    if (X[j] < 0) X[j] = rand.NextDouble() * noiseWave;
                    if (X[j] > 1) X[j] = 1 - rand.NextDouble() * noiseWave;
                }


                if (bestStepCount == 0)
                {
                    if (++noChangeCount > 4) break;
                }

            }

            return bestY;
        }



        //-----------------------------


        double minNeighbourV = 100;
        int DomainSetCount(double[] solutionX)
        {
           

            CopyDoubleArray(X, solutionX);

            Function_T_Value();

            minNeighbourV = 100;

            for (int i = 0; i < N; i++)
            {
                if (gx[i] < minNeighbourV) minNeighbourV = gx[i];

            }

            int count = 0;
            for (int i = 0; i < N; i++)
            {
                if (X[i] >= minNeighbourV) count++;                
            }

            return count;

        }


        public bool Solve(string graphFile,int tryCount=100)
        {

            int[,] graph = null;

            if (graphFile.EndsWith(".clq"))
            {
                graph = Graph.MatrixGraph.LoadGraph2(graphFile);
            }
            else
            {
                graph = Graph.MatrixGraph.LoadGraphMatrix(graphFile);
            }

            if (graph == null) return false;

            Matrix2AdjacencyList(graph);



            X = new double[N];
            gx = new double[N];
            derivativeX = new double[N];

            double[] bestX = new double[N];
            originalX = new double[N];


            


            System.DateTime startTime=System.DateTime.Now;



            double maxY = 0;
            int minDSCount = int.MaxValue;



            for (int i = 0; i < tryCount; i++)
            {
                double Y=GetOneSolution();

                if (maxY+0.05 < Y)                   // improve significantly
                {                   
                    maxY = Y;
                    
                    CopyDoubleArray(bestX, X);

                    int dsCount=DomainSetCount(bestX);

                    if (dsCount < minDSCount)
                    {
                        minDSCount = dsCount;

                        Console.WriteLine(" current best= " + minDSCount.ToString());
                    }
                }


            }
            Console.WriteLine(" best= " + minDSCount.ToString());

            TimeSpan elapsedTime = System.DateTime.Now - startTime;

            Console.WriteLine(" elapsed time=" + elapsedTime.TotalMilliseconds.ToString()+"ms");


            string s = "";

            int dsC = DomainSetCount(bestX);

            for (int i=0; i< N; i++)
            {
                if(bestX[i]>= minNeighbourV) 
                {
                    s+=i.ToString()+"\t" ;
                }
            }
            s += "\n";

            for (int i = 0; i < N; i++)
            {
                
                 s += i.ToString() + "\t"+ bestX[i].ToString("f2")+"\t";
               
            }

            return Tools.FileOP_Tool.Save(graphFile + "_gdo", dsC.ToString() + "\n" + s + "\n");

        }
    }



}
