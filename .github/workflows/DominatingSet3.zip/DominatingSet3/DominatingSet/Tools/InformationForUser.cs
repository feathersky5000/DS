using System;
using System.Collections.Generic;
using System.Text;

namespace Tools
{

    class Log
    {
        StringBuilder sBuilder = null;
 
        public Log( )
        {
            sBuilder = new StringBuilder();
        }

        public void Record(string s)
        {
            sBuilder.AppendLine(s);

            if (sBuilder.Length > 1000)
            {
                Tools.FileOP_Tool.AppendStringInFile("log.txt", sBuilder.ToString());

                sBuilder.Clear();
            }
        }

        public void Flush()
        {
            if (sBuilder.Length > 0)
            {
                Tools.FileOP_Tool.AppendStringInFile("log.txt", sBuilder.ToString());

                sBuilder.Clear();
            }
        }

        ~Log()
        {
            if (sBuilder == null) return;

            if (sBuilder.Length == 0) return;

            Tools.FileOP_Tool.AppendStringInFile("log.txt", sBuilder.ToString());

            sBuilder.Clear();
        }
    }


    public class InformationForUser
    {
        static StringBuilder sBuilder = new StringBuilder();

        static Log log = new Log();

        public static void Show(string s)
        {
            //MessageBox.Show(s);
            System.Console.WriteLine(s);

            log.Record(s);           
        }

        public static void Flush()
        {
            log.Flush();
        }

        public static void Show(string[] ss)
        {
            //MessageBox.Show(s);
            string s = "";
            for(int i=0; i<ss.Length; i++) s+=ss[i]+"\t";
            Show(s);
        }
    }
}
