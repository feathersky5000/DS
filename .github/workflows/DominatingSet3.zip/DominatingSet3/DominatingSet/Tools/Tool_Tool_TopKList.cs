﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tools
{
    class Tool_TopKList<T> 
    {

        public List<double> Keys = new List<double>();
        public List<T> Values = new List<T>();

        int TopK = 0;

        public Tool_TopKList(int _TopK)
        {
            TopK = _TopK;
        }


        public void Add(double key, T value)
        {
            
            //empty
            if(Keys.Count==0) 
            {
                 Keys.Add(key);
                 Values.Add(value);

                 return;
            }

            // not smaller than the last element
            if((Keys.Count==TopK) && (Keys[TopK-1]<key)) return;


            // other condition

            int i = Keys.Count - 1;

            for (; i >= 0; i--)
            {
                if (key > Keys[i]) break;
            }           
            
            Keys.Insert(i+1,key);
            Values.Insert(i+1,value);

            if (Keys.Count > TopK)
            {
                Keys.RemoveAt(TopK);
                Values.RemoveAt(TopK);
            }

        }

        public void Clear()
        {
            Keys.Clear();
            Values.Clear();
        }
    }
}
