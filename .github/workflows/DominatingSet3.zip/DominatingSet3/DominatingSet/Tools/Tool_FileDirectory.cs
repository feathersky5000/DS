﻿using System;
using System.Collections.Generic;
using System.Text;



using System.Drawing;



using System.IO;
using System.Collections;


using System.Reflection;
using System.Reflection.Emit;


using System.Runtime.InteropServices;


namespace Tools
{
    

    public class FileDirectory_Tool
    {
        public delegate void ProcessFileFunc(string file);


        public static void ProcessDirectory(string targetDirectory, ProcessFileFunc ProcessFileFunc)
        {
          
            if (!Directory.Exists(targetDirectory)) return;

            // Process the list of files found in the directory.
            string[] fileEntries = Directory.GetFiles(targetDirectory);
            foreach (string fileName in fileEntries)
                ProcessFileFunc(fileName);

            // Recurse into subdirectories of this directory.
            string[] subdirectoryEntries = Directory.GetDirectories(targetDirectory);
            foreach (string subdirectory in subdirectoryEntries)
                ProcessDirectory(subdirectory, ProcessFileFunc);
        }


        public static string[] ParseFilename(string filename)
        {

            string[] info = filename.Split('\\');

            string[] fileInfo = info[info.Length - 1].Split('.');

            return fileInfo;
        }


        




    

   }


}
