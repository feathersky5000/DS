﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tools
{
    public interface Tool_SerializationListObjectInterface
    {

        string ToString();
        void FromString(string str);       
    }



    public class Tool_SerializationObjectList<T> where T : Tool_SerializationListObjectInterface, new()
    {

        

        public static bool SerializeToFile(List<T> list, string file)
        {

            StringBuilder strBuilder = new StringBuilder();


            foreach (T obj in list) strBuilder.AppendLine(obj.ToString());


            return Tools.FileOP_Tool.Save(file, strBuilder.ToString());          
        }


        public static List<T> DeserializeFromFile(string file)
        {

           if(!System.IO.File.Exists(file)) return null;

           List<T> list = new List<T>();

           List<string> lines= Tools.FileOP_Tool.LoadListString(file);

           for(int i=0; i<lines.Count; i++)
           {
               string line = lines[i].Trim();

               if (line == "") continue;

               T obj = new T();

               obj.FromString(line);

               list.Add(obj);
           }


            return list;
        }
    }
}
