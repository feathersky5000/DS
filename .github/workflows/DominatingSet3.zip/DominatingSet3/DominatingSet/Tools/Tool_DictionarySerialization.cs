﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tools
{
    public class Tool_DictionarySerialization<TKey,TValue>
    {

        static string splitFlag = "*#*#*#*";

        public static bool SerializeToFile(Dictionary<TKey, TValue> dic, string file)
        {

            List<TKey> keys = new List<TKey>();
            List<TValue> values = new List<TValue>();


            foreach (TKey key in dic.Keys)
            {
                keys.Add(key);
                values.Add(dic[key]);
            }

            return Tools.FileOP_Tool.Save(file, XmlUtil.Serializer(keys) + splitFlag + XmlUtil.Serializer(values));          
        }


        public static Dictionary<TKey, TValue> DeserializeFromFile(string file)
        {

           if(!System.IO.File.Exists(file)) return null;

            string content=Tools.FileOP_Tool.Load(file);

            int index=content.IndexOf(splitFlag);




            List<TKey> keys = XmlUtil.Deserialize(typeof(List<TKey>), content.Substring(0, index)) as List<TKey>;

            List<TValue> values = XmlUtil.Deserialize(typeof(List<TValue>), content.Substring(index + splitFlag.Length, content.Length - (index + splitFlag.Length))) as List<TValue>;

       
             Dictionary<TKey, TValue> dic = new Dictionary<TKey, TValue>();

             for (int i = 0; i < keys.Count; i++) dic.Add(keys[i], values[i]);        


            return dic;
        }
    }
}
