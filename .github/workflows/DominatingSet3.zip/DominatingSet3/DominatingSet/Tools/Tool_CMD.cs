﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tools
{
    public class Tool_CMD
    {
        
    };

    public class Tool_CMD_F1<TResult>
    {
        public delegate TResult Func(params Type[] typeArguments);

        public Dictionary<string, Func> functions = new Dictionary<string, Func>();


        public void AddFunction(string name, Func func)
        {
            if (functions.ContainsKey(name))
            {
                Tools.InformationForUser.Show(name + " Function already exists");
                return;
            }
            
            functions.Add(name, func);
        }

        public bool Find(string name)
        {
            return functions.ContainsKey(name);
        }

        public bool Excute(string[] args)
        {
            Func func = functions[args[0]];

           // if (typeof(TP0) == typeof(double)) return func(double.Parse(args[1]));

            return true;
        }
    }
}
