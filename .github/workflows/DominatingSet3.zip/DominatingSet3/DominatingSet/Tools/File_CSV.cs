﻿using System;
using System.Collections.Generic;

using System.Text;

using System.IO;
using System.Collections;






using System.Reflection;
using System.Reflection.Emit;


using System.Runtime.InteropServices;


using System.Diagnostics;

using System.Text.RegularExpressions;


using System.Data;





namespace Tools
{
    public class File_CSV
    {
        // CSV seperatedSymbol value "\t" or ",";

        public static char seperatedSymbol = '\t';

        //将组织好的数组数据保存为CSV文件的代码：


        public static bool WriteDataTableToCSV(string filename, DataTable workTable)
        {

            if (workTable == null) return false;

            StreamWriter sw = new StreamWriter(filename, false, System.Text.Encoding.Default );

            StringBuilder builder = new StringBuilder();

            for (int k = 0; k < workTable.Columns.Count; k++)
            {
                builder.Append(workTable.Columns[k].ColumnName);

                if (k < workTable.Columns.Count - 1) builder.Append(seperatedSymbol);
            }

            builder.Append("\r\n");

          
            for (int i = 0; i < workTable.Rows.Count; i++)
            {
                DataRow workRow = workTable.Rows[i];

                for (int k = 0; k < workTable.Columns.Count; k++)
                {
                    string s = workRow[k].ToString().Replace(seperatedSymbol, ' ');

                    s = s.Replace("\r\n", "");

                    s = s.Replace("\n", "");

                    builder.Append(s);

                    if (k < workTable.Columns.Count - 1) builder.Append(seperatedSymbol);
                }

                builder.Append("\r\n");
            }


            sw.Write(builder.ToString());

            sw.Flush();
            sw.Close();

            return true;

        }


        public static DataTable ReadDataTableFromCSV(string filename)
        {
            try
            {
                if (filename == null) return null;

                StreamReader reader = new StreamReader(filename, System.Text.Encoding.Default);

                DataTable workTable = new DataTable();


                int readLine = 0;
                string str = "";
                while (str != null)
                {
                    str = reader.ReadLine();
                    if ((str != null) && (str.Length > 0))
                    {
                        string[] items = str.Split(seperatedSymbol);

                        if (readLine == 0)
                        {
                            for (int i = 0; i < items.Length; i++)
                            {
                                workTable.Columns.Add(items[i], typeof(String));
                            }
                        }
                        else
                        {
                            DataRow workRow = workTable.NewRow();

                            int c = workTable.Columns.Count;

                            if (c > items.Length) c = items.Length;

                            for (int i = 0; i < c; i++)
                            {
                                workRow[i] = items[i];
                            }
                            workTable.Rows.Add(workRow);
                        }


                        readLine++;
                    }
                }

                reader.Close();


                return workTable;
            }
            catch (Exception e)
            {
              
                InformationForUser.Show("Read CSV file Error: " + e.ToString());


                return null;
            }
        }



        public static bool WriteDataTableToCSVWithoutCaptions(string filename, DataTable workTable)
        {

            if (workTable == null) return false;

            StreamWriter sw = new StreamWriter(filename, false, System.Text.Encoding.Default);

            StringBuilder builder = new StringBuilder();

            //for (int k = 0; k < workTable.Columns.Count; k++)
            //{
            //    builder.Append(workTable.Columns[k].ColumnName);

            //    if (k < workTable.Columns.Count - 1) builder.Append(seperatedSymbol);
            //}

            //builder.Append("\r\n");


            for (int i = 0; i < workTable.Rows.Count; i++)
            {
                DataRow workRow = workTable.Rows[i];

                for (int k = 0; k < workTable.Columns.Count; k++)
                {
                    string s = workRow[k].ToString().Replace(seperatedSymbol, ' ');

                    s = s.Replace("\r\n", "");

                    s = s.Replace("\n", "");

                    builder.Append(s);

                    if (k < workTable.Columns.Count - 1) builder.Append(seperatedSymbol);
                }

                builder.Append("\r\n");
            }


            sw.Write(builder.ToString());

            sw.Flush();
            sw.Close();

            return true;

        }


        public static DataTable ReadDataTableFromCSVWithoutCaptions(string filename)
        {
            try
            {
                if (filename == null) return null;

                StreamReader reader = new StreamReader(filename, System.Text.Encoding.Default);

                DataTable workTable = new DataTable();


                int readLine = 0;
                string str = "";
                while (str != null)
                {
                    str = reader.ReadLine();
                    if ((str != null) && (str.Length > 0))
                    {
                        string[] items = str.Split(seperatedSymbol);

                        if (readLine == 0)
                        {
                            for (int i = 0; i < items.Length; i++)
                            {
                                workTable.Columns.Add("item"+i.ToString(), typeof(String));
                            }
                        }
                      
                        {
                            DataRow workRow = workTable.NewRow();

                            int c = workTable.Columns.Count;

                            if (c > items.Length) c = items.Length;

                            for (int i = 0; i < c; i++)
                            {
                                workRow[i] = items[i];
                            }
                            workTable.Rows.Add(workRow);
                        }


                        readLine++;
                    }
                }

                reader.Close();


                return workTable;
            }
            catch (Exception e)
            {

                InformationForUser.Show("Read CSV file Error: " + e.ToString());


                return null;
            }
        }



        //public static bool WriteDataTableToCSV(string filename, DataTable workTable)
        //{
        //    return WriteListStringArrayToCSV(filename, DataTableToListStringArray(workTable));
        //}

        //public static DataTable ReadDataTableFromCSV(string filename)
        //{
        //    return ListStringArrayToDataTable(ReadListStringArrayFromCSV(filename));
        //}

        //--------------------------------------------------

        public static  DataTable ListStringArrayToDataTable(List<string[]> ListStringArray)
        {
            DataTable workTable = new DataTable();


            for (int i = 0; i < ListStringArray[0].Length; i++)
            {
                workTable.Columns.Add(ListStringArray[0][i], typeof(String));
            }

            for (int row = 1; row < ListStringArray.Count; row++)
            {
                DataRow workRow = workTable.NewRow();

                for (int k = 0; k < ListStringArray[row].Length-1; k++) workRow[k] = ListStringArray[row][k];
               
                workTable.Rows.Add(workRow);
            }

            return workTable;

        }



        public static List<string[]> DataTableToListStringArray(DataTable workTable)
        {
            List<string[]> ListStringArray = new List<string[]>();


            {
                string[] row = new string[workTable.Columns.Count];

                for (int i = 0; i < workTable.Columns.Count; i++) row[i] = workTable.Columns[i].ToString();

                ListStringArray.Add(row);
            }



            for (int n = 0; n < workTable.Rows.Count; n++)
            {
                string[] row = new string[workTable.Columns.Count];

                for (int i = 0; i < workTable.Columns.Count; i++) row[i] = workTable.Rows[n][i].ToString();

                ListStringArray.Add(row);
            }

            return ListStringArray;

        }

        //--------------------------------------------------
        public static List<string[]> ReadListStringArrayFromCSV(string filename)
        {

            try
            {
                if (filename == null) return null;

                List<string[]> ListStringArray = new List<string[]>();

                StreamReader reader = new StreamReader(filename, System.Text.Encoding.Default);
               
                string str = "";
                while (str != null)
                {
                    str = reader.ReadLine();     

                    if ((str != null) && (str.Length > 0))
                    {
                        if (str.EndsWith(seperatedSymbol.ToString())) str = str.Remove(str.Length - 1);

                        string[] items = str.Split(seperatedSymbol);                     

                        ListStringArray.Add(items);                      
                    }
                }

                reader.Close();

                return ListStringArray;
            }
            catch (Exception e)
            {
               
                InformationForUser.Show("Read ListStringArray file Error: " + e.ToString());
                return null;
            }
        }

        public static bool WriteListStringListToCSV(string filename, List<List<string>> ListStringList)
        {
            List<string[]> listArray = new List<string[]>();

            for (int i = 0; i < ListStringList.Count; i++)
            {
                string[] array = new string[ListStringList[i].Count];

                for (int j = 0; j < ListStringList[i].Count; j++) array[j] = ListStringList[i][j];

                listArray.Add(array);
            }

            return WriteListStringArrayToCSV(filename, listArray);


        }


        public static bool WriteListStringArrayToCSV(string filename, List<string[]> ListStringArray)
        {

            if (ListStringArray == null) return false;

            StreamWriter sw = new StreamWriter(filename, false, System.Text.Encoding.Default);

            StringBuilder builder = new StringBuilder();


            int count = ListStringArray[0].Length-1;

            for (int i = 0; i < ListStringArray.Count; i++)
            {
                int k =0;

                for ( k = 0; k < ListStringArray[i].Length; k++)
                {
                    string s = ListStringArray[i][k].Replace(seperatedSymbol, ' ');

                    s = s.Replace("\r\n", "");

                    s = s.Replace("\n", "");

                    builder.Append(s);

                    if (k < ListStringArray[i].Length - 1) builder.Append(seperatedSymbol);
                }
              
                builder.Append("\r\n");

            }


            sw.Write(builder.ToString());
            
            sw.Flush();
            sw.Close();

            return true;

        }




        //--------------------------------------------------
        public static double[,] ReadDoubleArrayFromCSV(string filename)
        {

            try
            {
                if (filename == null) return null;

                List<string[]> listStringArray = ReadListStringArrayFromCSV(filename);


                double[,] values = new double[listStringArray.Count, listStringArray[0].Length];


                for (int i = 0; i < listStringArray.Count; i++)
                {
                    for (int j = 0; j < listStringArray[0].Length; j++)
                    {
                        try
                        {                          
                            
                            values[i, j] = double.Parse(listStringArray[i][j]);

                        }
                        catch
                        {
                        }
                    }
                }

                return values;               

            }
            catch (Exception e)
            {
                
                InformationForUser.Show("Read ListStringArray file Error: " + e.ToString());
                return null;
            }
        }


        public static bool WriteDoubleArrayToCSV(string filename, double[,] values)
        {
            StreamWriter sw = new StreamWriter(filename, false, System.Text.Encoding.Default);

            StringBuilder builder = new StringBuilder();


            int count0 = values.GetLength(0);
            int count1 = values.GetLength(1);

            for (int i = 0; i < count0; i++)
            {
                for (int k = 0; k < count1; k++)
                {
                    builder.Append(values[i,k].ToString() );

                    if (k < count1 - 1) builder.Append(seperatedSymbol);
                }

                builder.Append("\r\n");

            }


            sw.Write(builder.ToString());

            sw.Flush();
            sw.Close();

            return true;


        }



        //-------------------------------------

        public static bool TransformDoubleArray(string srcFile,string dstFile)
        {
            double[,] data = Tools.File_CSV.ReadDoubleArrayFromCSV(srcFile);


            int count = data.GetLength(0);
            int length = data.GetLength(1);


            double[,] transformData = new double[length, count];

            for (int i = 0; i < count; i++)
            {
                for (int j = 0; j < length; j++)
                {
                    transformData[j, i] = data[i, j];
                }
            }


            return WriteDoubleArrayToCSV(dstFile,transformData);

        }




        //--------------------------------------------------
        public static Int16[,] ReadInt16ArrayFromCSV(string filename)
        {
           
            try
            {
                if (filename == null) return null;

                List<int[]> listIntArray = new List<int[]>();

                StreamReader reader = new StreamReader(filename, System.Text.Encoding.Default);

                string str = "";
                while (str != null)
                {
                    str = reader.ReadLine();

                    if ((str != null) && (str.Length > 0))
                    {
                        if (str.EndsWith(seperatedSymbol.ToString())) str = str.Remove(str.Length - 1);

                        string[] items = str.Split(seperatedSymbol);

                        int[] oneRowValue=new int[items.Length];

                        for (int i = 0; i < items.Length; i++) oneRowValue[i] = Int16.Parse(items[i]);

                        listIntArray.Add(oneRowValue); 

                    }
                }

                reader.Close();


                Int16[,] values = new Int16[listIntArray.Count, listIntArray[0].Length];

                for(int i=0; i<listIntArray.Count; i++)
                {
                    for(int j=0; j<listIntArray[i].Length; j++)
                    {
                        values[i, j] = (Int16)listIntArray[i][j];
                    }

                }

               return values;
            }
            catch (Exception e)
            {
                InformationForUser.Show("Read ListStringArray file Error: " + e.ToString());
                return null;
            }


          
        }


        public static int[,] ReadIntArrayFromCSV(string filename)
        {

            try
            {
                if (filename == null) return null;

                List<int[]> listIntArray = new List<int[]>();

                StreamReader reader = new StreamReader(filename, System.Text.Encoding.Default);

                string str = "";
                while (str != null)
                {
                    str = reader.ReadLine();

                    if ((str != null) && (str.Length > 0))
                    {
                        if (str.EndsWith(seperatedSymbol.ToString())) str = str.Remove(str.Length - 1);

                        string[] items = str.Split(seperatedSymbol);

                        int[] oneRowValue = new int[items.Length];

                        for (int i = 0; i < items.Length; i++) oneRowValue[i] = int.Parse(items[i]);

                        listIntArray.Add(oneRowValue);

                    }
                }

                reader.Close();


                int[,] values = new int[listIntArray.Count, listIntArray[0].Length];

                for (int i = 0; i < listIntArray.Count; i++)
                {
                    for (int j = 0; j < listIntArray[i].Length; j++)
                    {
                        values[i, j] = (int)listIntArray[i][j];
                    }

                }

                return values;
            }
            catch (Exception e)
            {
                InformationForUser.Show("Read ListStringArray file Error: " + e.ToString());
                return null;
            }



        }


        public static bool WriteByteArrayToCSV(string filename, Byte[,] values)
        {
            StreamWriter sw = new StreamWriter(filename, false, System.Text.Encoding.Default);

            StringBuilder builder = new StringBuilder();


            int count0 = values.GetLength(0);
            int count1 = values.GetLength(1);

            for (int i = 0; i < count0; i++)
            {
                for (int k = 0; k < count1; k++)
                {
                    builder.Append(values[i, k].ToString());

                    if (k < count1 - 1) builder.Append(seperatedSymbol);
                }

                builder.Append("\r\n");

            }


            sw.Write(builder.ToString());

            sw.Flush();
            sw.Close();

            return true;


        }


        public static bool WriteIntArrayToCSV(string filename, int[,] values)
        {
            StreamWriter sw = new StreamWriter(filename, false, System.Text.Encoding.Default);

            StringBuilder builder = new StringBuilder();


            int count0 = values.GetLength(0);
            int count1 = values.GetLength(1);

            for (int i = 0; i < count0; i++)
            {
                for (int k = 0; k < count1; k++)
                {
                    builder.Append(values[i, k].ToString());

                    if (k < count1 - 1) builder.Append(seperatedSymbol);
                }

                builder.Append("\r\n");

            }


            sw.Write(builder.ToString());

            sw.Flush();
            sw.Close();

            return true;


        }

    }

}
