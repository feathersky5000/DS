using System;
using System.Collections.Generic;
using System.Text;


//  -------------2014-05-28--------------


namespace Tools
{
    class Tool_ListIntOperation
    {
        public static List<int> Clone(List<int> list)
        {
            List<int> newList = new List<int>();

            for (int i = 0; i < list.Count; i++) newList.Add(list[i]);
            
            return newList;
        }

        public static int[] StrToIntArray(string str, char splitSymbol)
        {
            str = str.Trim().Trim(splitSymbol);

            string[] items = str.Split(splitSymbol);


            int[] array = new int[items.Length];

            for (int i = 0; i < array.Length; i++) array[i] = int.Parse(items[i]);

            return array;
        }


        public static List<int> StrToIListInt(string str, char splitSymbol)
        {

            List<int> list = new List<int>();          

            string[] items = str.Split(new char[] { splitSymbol }, StringSplitOptions.RemoveEmptyEntries);


            for (int i = 0; i < items.Length; i++) list.Add (int.Parse(items[i]));

            return list;
        }



        public static List<int> LoadListIntFromFile(string file)
        {
            string str = Tools.FileOP_Tool.Load(file);

            str = str.Replace("\r\n", "");


            return StrToIListInt(str, '\t');

        }

        public static bool SaveListIntToFile(List<int> list, string file)
        {
            string str = ListIntToStr(list,'\t');

            return Tools.FileOP_Tool.Save(file, str);
                     
        }



        public static string ListIntToStr(List<int> list, char splitSymbol)
        {
            string str = "";

            for (int i = 0; i < list.Count; i++) str += list[i].ToString()+splitSymbol;

            return str;
        }




        public static List<int> MergeListWithoutRepeatedElement(List<int> list1, List<int> list2)
        {

            for (int i = 0; i < list2.Count; i++)
            {
                if (!list1.Contains(list2[i])) list1.Add(list2[i]);
            }

            return list1;
        }
    }
}
