﻿using System;
using System.Collections.Generic;

using System.Text;

namespace Tools
{
    class StringOP_Tool
    {

        public static int Index(string[] strArray, string dstStr)
        {           

            for (int i = 0; i < strArray.Length; i++)
            {
                if (strArray[i] == dstStr)
                {
                    return i;
                }
            }

            return -1;
        }



        //返回最长串长度     

        public static int LCS_Similarity(string s1, string s2)
        {
            int l = LCS_Length(s1, s2);

            if (l > 0) return l * 50 / s1.Length + l * 50 /s2.Length;

            return 0;
        }


        public static int LCS_Length(string s1, string s2)
        {

            int[,] lcs = new int[s1.Length + 1, s2.Length + 1];



            for (int m = 0; m < s1.Length + 1; m++)
            {
                for (int n = 0; n < s2.Length + 1; n++)
                {
                    if ((m < 1) || (n < 1))
                    {
                        lcs[m, n] = 0;
                        continue;
                    }

                    int a1 = lcs[m - 1, n - 1];

                    int a = Math.Max(lcs[m - 1, n], lcs[m, n - 1]);

                    if (lcs[m - 1, n - 1] == a)// LCS( m-1,n-1) is the longest, n th  cann't match (1,m-1), m cann't match (1,n-1)
                    {
                        if (s1[m - 1] == s2[n - 1])   // string count start at 0,we shift it to 1
                            lcs[m, n] = a + 1;
                        else
                            lcs[m, n] = a;

                        continue;
                    }

                    lcs[m, n] = a;


                }
            }

            return lcs[s1.Length, s2.Length];

        }


        //其实你只要掌握汉字的编码范围4e00-9fa5就行了，\u是一个转义字符，表示由4位16进制数字制定的Unicode字符
        public static string ExtractChinese(string s)
        {
            return System.Text.RegularExpressions.Regex.Replace(s, "[^\u4e00-\u9fa5]+", ""); 
        }

        public static bool IsChinese(char c)
        {
            const char c1='\u4e00';
            const char c2 = '\u9fa5';

            return ((c>c1)&&(c<c2));
        }
  
    }
}
