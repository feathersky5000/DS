﻿using System;
using System.Collections.Generic;
using System.Text;



using System.IO;
using System.Collections;



namespace Tools
{


    public class FileOP_Tool
    {
        public static string Load(string file, Encoding encoding)
        {
            string code = null;

            try
            {
                StreamReader reader = new StreamReader(file, encoding);

                code = reader.ReadToEnd();

                reader.Close();                

                return code;
            }
            catch
            {
                return null;
            }
        }



        public static string Load(string file)
        {
            return Load(file, Encoding.Default);
        }



        public static bool Save(string filename, string content, Encoding encoding)
        {
            try
            {

                string dir=Tools.FileOP_Tool.GetFilePath(filename);

                if (dir != "")
                {
                    if (!System.IO.Directory.Exists(dir)) System.IO.Directory.CreateDirectory(dir);
                }

                //设置字符编码很重要，否则会得到乱码         
                StreamWriter sw = new StreamWriter(filename, false, encoding);

                sw.Write(content);

                
                sw.Close();

                return true;
            }
            catch
            {
                return false;
            }
        }

        public static bool Save(string filename, string content)
        {
            return Save(filename, content, Encoding.Default);
        }







        public static bool AppendStringInFile(string filename, string content)
        {
            try
            {
                //设置字符编码很重要，否则会得到乱码         
                using (StreamWriter sw = new StreamWriter(filename, true, Encoding.Default))
                {
                    sw.Write(content);

                    sw.Close();

                    return true;
                }
            }
            catch
            {
                return false;
            }

        }


        //-----------------------------------------------

        public static bool SaveArray<T>(string filename, T[] values)
        {

            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < values.Length; i++)
            {
                sb.AppendLine(values[i].ToString());              
            }

            return Tools.FileOP_Tool.Save(filename, sb.ToString());

        }


        public static double[] LoadDoubleArray(string filename)
        {

            string s = Tools.FileOP_Tool.Load(filename);

            string[] items = s.Replace("\r", "").Split('\n');

            int count = 0;
            for (; count < items.Length; count++)
            {
                if (items[count].Trim() == "") break;
            }

            double[] values = new double[count];

            for (int i = 0; i < count; i++)
            {               
                values[i] = double.Parse(items[i].Trim());
            }

            return values;

        }


        //-----------------------------------------------


        


        //---------------------------- char[]  file operation ----------

        public static bool Save(string filename, char[] buffer, int size)
        {
            try
            {
                //设置字符编码很重要，否则会得到乱码         
                using (StreamWriter sw = new StreamWriter(filename, false))
                {

                    sw.Write(buffer, 0, size);

                   // sw.Close();

                    return true;
                }
            }
            catch
            {
                return false;
            }
        }


        public static int Load(string file,char[] buffer)
        {        

            try
            {               
                StreamReader reader = new StreamReader(file);              
                
                int realSize=reader.Read(buffer, 0, buffer.Length);

                reader.Close();

                return realSize;
            }
            catch
            {
                return 0;
            }
        }

       


        public static StringBuilder LoadLines(string file,int start,int count)
        {

            StringBuilder sBuilder = new StringBuilder();

            try
            {
                StreamReader reader = new StreamReader(file);

                string s="";

                for (int i = 0; i < start; i++) s = reader.ReadLine();
               

                for (int i = 0; i < count && (!reader.EndOfStream); i++) sBuilder.AppendLine(reader.ReadLine());
              
                reader.Close();

                return sBuilder;
            }
            catch
            {
                return sBuilder;
            }
        }

        public static int LinesOfFile(string file)
        {

            int lines = 0;

            try
            {
                StreamReader reader = new StreamReader(file);

                string s = "";

                while (!reader.EndOfStream)
                {
                    s = reader.ReadLine();
                    lines++;
                }
             

                reader.Close();

                return lines;
            }
            catch
            {
                return lines;
            }
        }


        public static List<string> LoadListString(string filename)
        {
            string s = Load(filename);

            s=s.Replace("\r","");

            string[] lines = s.Split('\n');

            List<string> list=new List<string>();

            foreach (string line in lines) list.Add(line);

            return list;

        }

        //-----------------------------------------------------------

        public static void ExactFrontContent(string srcFile, string dstFile, int lineCount)
        {
            string code = "";

            try
            {
                StreamReader reader = new StreamReader(srcFile, Encoding.Default);              

                for (int i = 0; i < lineCount; i++)
                {
                    code += reader.ReadLine();
                    code += "\n";
                }

                reader.Close();

                Save(dstFile, code);
            }
            catch
            {
                
            }
        }


        public static void SplitFile(string srcFile,int size)
        {
           // string code = "";

            try
            {
                StreamReader reader = new StreamReader(srcFile, Encoding.Default);

                char[] buffer=new char[size];


                int i=-1,count=0,index=0;

                while ((count = reader.ReadBlock(buffer, 0, size)) > 0)
                {
                    index += count;
                    i++;

                    string filename = srcFile + "_split_" + i.ToString();

                    Save(filename, new string(buffer,0,count));

                }

                
                reader.Close();

               
            }
            catch(Exception e)
            {
                //MessageBox.Show(e.ToString());

                System.Console.WriteLine(e.ToString());

            }
        }

        public static void MergeMultiFilesInOneFile(string dstFile, List<string> srcFiles)
        {

            MergeMultiFilesInOneFile(srcFiles, dstFile);
        }


        
        public static void MergeMultiFilesInOneFile( List<string> srcFiles, string dstFile)
        {

            string s = "";
            for (int i = 0; i < srcFiles.Count; i++)
            {
                if (System.IO.File.Exists(srcFiles[i]))
                    s += Load(srcFiles[i]);          
            }
            Save(dstFile, s);
           
        }


        //-----------------------------------------

        public static void RemoveEmptyLine(string file)
        {
            string s = Load(file);

            s = s.Replace("\r\n\r\n\r\n", "\r\n");
            s = s.Replace("\r\n\r\n", "\r\n");   
           

            Save(file, s);
        }




        //-----------------------------------------

        public static void ConvertPairwiseDifferencesToMatrix(string srcFile)
        {

            string s = Load(srcFile);
            string dstFile = srcFile + "_matrix";

            s=s.Replace('\r',' ').Replace('\n',' ');


            string[] items = s.Split(' ');


            int count = 0;
            for (int i = 0; i < items.Length; i++)
            {
                items[i] = items[i].Trim();

                if (items[i].Length > 0) count++;
            }


            int k=(int)Math.Round(1+Math.Sqrt(1+4*count))/2;


            List<int> indexes = new List<int>();

            for (int i = 0; i < k-1; i++)
            {
                for (int j = i + 1; j < k; j++)
                {
                    indexes.Add(i);
                    indexes.Add(j);
                    indexes.Add(j);
                    indexes.Add(i);                
                }
            }



            int[,] matrix = new int[k, k];

            for (int i = 0; i < k; i++) matrix[i, i] = 0;

            int index = 0;

            for (int i = 0; i < items.Length; i++)
            {
                if(items[i].Length==0) continue;               

                matrix[indexes[2 * index], indexes[2 * index + 1]] = int.Parse(items[i]);

                index++;

            }

            File_CSV.WriteIntArrayToCSV(dstFile, matrix);

        }

        //-----------------------------------------

        public static string GetFilePath(string filename)
        {
            int t=filename.LastIndexOf('\\');

            if (t < 0) return "";

            return  filename.Substring(0, t)+"\\";
        }

        public static string GetFileName(string filename)
        {
            int t = filename.LastIndexOf('\\');            

            return filename.Substring(t+1,filename.Length-t-1);
        }

        public static string GetFileNameWithoutPostfix(string filename)
        {
            int t = filename.LastIndexOf('\\');
            int t2 = filename.LastIndexOf('.');

            return filename.Substring(t+1, t2-t-1);
        }

        public static string GetFilePostfix(string filename)
        {
            int t = filename.LastIndexOf('.');
            return filename.Substring(t+1, filename.Length - t-1).ToLower();
        }


      

        
        /// "../../../filename"
       
        public static string CombineFilename(string path,string relativePathFile)
        {
          
            path=path.TrimEnd('\\');

            string up="../";
            while (relativePathFile.IndexOf(up)==0)
            {
                relativePathFile = relativePathFile.Substring(up.Length, relativePathFile.Length - up.Length);

                path=path.Substring(0,path.LastIndexOf('\\'));
            }

            up = "..\\";
            while (relativePathFile.IndexOf(up) == 0)
            {
                relativePathFile = relativePathFile.Substring(up.Length, relativePathFile.Length - up.Length);

                path = path.Substring(0, path.LastIndexOf('\\'));
            }


            return path +"\\"+ relativePathFile;

        }

        public static string CombineFilename( string relativePathFile)
        {
            return CombineFilename(  System.Environment.CurrentDirectory, relativePathFile);
        }


      
    }


}
