using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tools
{
    public class Tool_DigitConvert
    {
        public static string DigitToStr(int digit, int count, int digitBase)
        {

            string str = "";           

            for (int i = 0; i < count; i++)
            {

                str += ((digit / (int)(Math.Pow(digitBase, count - i - 1))) % digitBase) .ToString();
            }

            return str;

           
        }
    }
}
