﻿using System;
using System.Collections.Generic;

using System.Text;


namespace Tools
{
    public class Config
    {

        public string configFile="config.xml";

        public Dictionary<string, string> infos = new Dictionary<string, string>();     

        public Config(string _configFile)
        {
            configFile = _configFile;

            if (System.IO.File.Exists(configFile))
            {
                infos = Tools.Tool_SerializationDictionary<string, string>.DeserializeFromFile(configFile);

            }
        }


        public string this[string key]
        {
            get
            {
                if (infos.ContainsKey(key)) return infos[key];

                return null;
            }
            set
            {
                if (!infos.ContainsKey(key))
                    infos.Add(key, value);
                else
                    infos[key] = value;
            }
        }


        ~Config()
        {
            Tools.Tool_SerializationDictionary<string,string>.SerializeToFile(infos, configFile);
        }
    }
}
