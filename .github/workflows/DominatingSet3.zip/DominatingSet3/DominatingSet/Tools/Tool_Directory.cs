﻿using System;
using System.Collections.Generic;
using System.Text;



using System.Drawing;



using System.IO;
using System.Collections;


using System.Reflection;
using System.Reflection.Emit;


using System.Runtime.InteropServices;


namespace Tools
{
    

    public class Directory_Tool
    {
        public delegate void ProcessFileFunc(string file);


        public static void ProcessDirectory(string destinationDirectory, ProcessFileFunc ProcessFileFunc)
        {
          
            if (!Directory.Exists(destinationDirectory)) return;

            // Process the list of files found in the directory.
            string[] fileEntries = Directory.GetFiles(destinationDirectory);
            foreach (string fileName in fileEntries)
                ProcessFileFunc(fileName);

            // Recurse into subdirectories of this directory.
            string[] subdirectoryEntries = Directory.GetDirectories(destinationDirectory);
            foreach (string subdirectory in subdirectoryEntries)
                ProcessDirectory(subdirectory, ProcessFileFunc);
        }

        public static void CopyDirectory(string destinationDirectory, string sourceDirectory)
        {

            if (!Directory.Exists(sourceDirectory)) return;

            if (!Directory.Exists(destinationDirectory)) System.IO.Directory.CreateDirectory(destinationDirectory);

            foreach (string file in System.IO.Directory.GetFiles(sourceDirectory))
            {
                string newFile = file.Replace(sourceDirectory, destinationDirectory);

                System.IO.File.Copy(file, newFile);
            }            
        }

   }


}
