﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graph
{
    class MatrixGraph
    {
        public static int[,] LoadGraphMatrix(string graphFile)
        {
            int[,] graph = Tools.File_CSV.ReadIntArrayFromCSV(graphFile);

           
            int vertexNum=graph.GetLength(0);


            for(int i=0; i<vertexNum; i++)
            {
                for(int j=i+1; j<vertexNum; j++)
                {
                    if(graph[i,j]!=graph[j,i])
                    {
                        Tools.InformationForUser.Show(graphFile+": graph error at locus i="+i.ToString()+" j="+j.ToString());
                    }
                }
            }

            return graph;
        }






        //e 125 118
        //e 125 119
        //e 125 120
        //e 125 121
        //e 125 122
        //e 125 123
        //e 125 124

        public static int[,] LoadGraph2(string graphFile)
        {

            try
            {
                List<string> lines = Tools.FileOP_Tool.LoadListString(graphFile);

                while (true)
                {
                    string line = lines[lines.Count - 1].Trim();

                    if (line.Length < 3)
                        lines.RemoveAt(lines.Count - 1);
                    else
                        break;
                }

                string lastLine = lines[lines.Count - 1];

                string[] items = lastLine.Split(' ');

                int vertexNum = int.Parse(items[1]);

                int[,] graph = new int[vertexNum, vertexNum];


                for (int i = 0; i < vertexNum; i++)                
                    for (int j = i + 1; j < vertexNum; j++)
                        graph[i, j] = 0;

                int edgeCount = 0;

                foreach(string line in lines)
                {
                    items = line.Split(' ');
                    if (items.Length != 3) continue;

                    if (items[0] != "e") continue;

                    int from = int.Parse(items[1])-1;
                    int to = int.Parse(items[2])-1;

                    graph[from, to] = graph[to, from] = 1;

                    edgeCount++;
                }

                Tools.InformationForUser.Show("load graph " + graphFile + " #vertex=" + vertexNum.ToString()+ " #edge= " + edgeCount.ToString());
                return graph;
            }
            catch(Exception e)
            {
                Tools.InformationForUser.Show(e.ToString());

                return null;
            }
        }




        public static bool SaveGraphMatrix(string graphFile,int[,] graph)
        {
            return Tools.File_CSV.WriteIntArrayToCSV(graphFile, graph);
        }



        public static int[,] RandomGraph(int vertexNum,int edgeCount)
        {
            int[,] newGraph = new int[vertexNum, vertexNum];

            for (int i = 0; i < vertexNum; i++)
            {
                for (int j = 0; j < vertexNum; j++)
                {
                    newGraph[i, j] = 0;                    
                }
            }


            Random rand = new Random();

            int count = 0;
          

            while(count<edgeCount)
            {
                int v1 = rand.Next(vertexNum);
                int v2 = rand.Next(vertexNum);

                if (v1 == v2) continue;

                if (newGraph[v1, v2] == 1) continue;

                newGraph[v1, v2] = 1;
                newGraph[v2, v1] = 1;

                count++;
            }

            return newGraph;
        }


        public static int[,] RandomConnectedGraph(int vertexNum, int edgeCount)
        {

            int[,] newGraph = RandomGraph(vertexNum, edgeCount);

            bool bIsolated = true;

            Random rand=new Random();

            for (int i = 0; i < vertexNum; i++)
            {
                bIsolated = true;

                for (int j = 0; j < vertexNum; j++)
                {
                    if (newGraph[i, j] == 1)
                    {
                        bIsolated = false;
                        break;
                    }
                }

                if (bIsolated)
                {
                    int t=rand.Next(vertexNum);

                    while(t==i) t=rand.Next(vertexNum);
                   
                    newGraph[i, t] = 1;
                    newGraph[t, i] = 1;
                }
            }

            

            return newGraph;
        }

        public static bool  RandomPermutateGraphVertex(string graphSrcFile, string graphDstFile)
        {
            int[,] graph = LoadGraphMatrix(graphSrcFile);

            int vertexNum = graph.GetLength(0);

            

            string graphEdgeInfo = "";

            for (int i = 0; i < vertexNum; i++)
            {
                for (int j = 0; j < vertexNum; j++)
                {
                    if (graph[i, j] == 1) graphEdgeInfo += "v" + i.ToString().PadLeft(5, '0') + "v" + j.ToString().PadLeft(5, '0') + "#";
                }
            }

            Random rand = new Random();

            for (int i = 0; i < vertexNum/4; i++)
            {
                int v1 = rand.Next(vertexNum);
                int v2 = rand.Next(vertexNum);

                string strV1 = "v" + v1.ToString().PadLeft(5,'0');
                string strV2 = "v" + v2.ToString().PadLeft(5, '0'); 

                graphEdgeInfo = graphEdgeInfo.Replace(strV1, "*");

                graphEdgeInfo = graphEdgeInfo.Replace(strV2, strV1);

                graphEdgeInfo = graphEdgeInfo.Replace("*", strV2);
            }

            int[,] newGraph = new int[vertexNum, vertexNum];

            for (int i = 0; i < vertexNum; i++)
            {
                for (int j = 0; j < vertexNum; j++)
                {
                    newGraph[i, j] = 0;

                    string edge = "v" + i.ToString().PadLeft(5, '0') +"v" + j.ToString().PadLeft(5, '0'); 

                    if (graphEdgeInfo.IndexOf(edge) >= 0) newGraph[i, j] = 1;
                }
            }

            return Tools.File_CSV.WriteIntArrayToCSV(graphDstFile, newGraph);
        }


        public static bool BatchRandomConnectedGraph(int count,int minVertexNum,int maxVertexNum)
        {

            Random rand = new Random();

            for (int i = 0; i < count; i++)
            {
                string sGraph = "graphSS*.txt";
                string dGraph = "graphDD*.txt";

                sGraph = sGraph.Replace("*", i.ToString());
                dGraph = dGraph.Replace("*", i.ToString());


                int vertexNum = rand.Next(minVertexNum, maxVertexNum);

                int edgeNum = rand.Next(1, vertexNum * (vertexNum - 1) / 2);

                int[,] graphS = MatrixGraph.RandomConnectedGraph(vertexNum, edgeNum);

                MatrixGraph.SaveGraphMatrix(sGraph, graphS);

                MatrixGraph.RandomPermutateGraphVertex(sGraph, dGraph);
            }


            return true;
        }
    }
}
