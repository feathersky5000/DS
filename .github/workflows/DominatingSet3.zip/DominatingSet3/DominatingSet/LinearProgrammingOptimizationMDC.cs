﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DominatingSet
{
    class LinearProgrammingOptimizationMDC
    {
        
        
        //-----------------------------

        public static bool Solve(int[,] graph, string file)
        {

            int N = graph.GetLength(1);


            StringBuilder lp = new StringBuilder();

            lp.Append("min=");

            for (int i = 0; i < N; i++) lp.Append("x" + i.ToString()+"+");

            lp=lp.Remove( lp.Length - 1,1);

            lp.AppendLine(";");


            for (int i = 0; i < N; i++)
            {
                graph[i, i] = 1;

                string constraint = "";

                for (int j = 0; j < N; j++)
                {
                    if(graph[i,j]==1)
                    {
                        constraint+="x" + j.ToString()+"+";
                    }
                }

                lp.AppendLine(constraint.Substring(0, constraint.Length - 1) + ">=1;");
            }


            for (int i = 0; i < N; i++) lp.AppendLine("@bin(x" + i.ToString() + ");");

            return Tools.FileOP_Tool.Save(file, lp.ToString());
        }

        public static bool Solve(string graphFile)
        {

            int[,] graph = null;

            if (graphFile.EndsWith(".clq"))
            {
                graph = Graph.MatrixGraph.LoadGraph2(graphFile);
            }
            else
            {
                graph = Graph.MatrixGraph.LoadGraphMatrix(graphFile);
            }

            if (graph == null) return false;

            return Solve(graph, graphFile + "_lp");
        }

    }
}
