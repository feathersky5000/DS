﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DominatingSet
{
    class Program
    {

      

        static void Main(string[] args)
        {


            if (args.Length > 1)
            {
                if (args[0] == "generate")
                {
                    int[,] graphS = Graph.MatrixGraph.RandomConnectedGraph(int.Parse(args[1]), int.Parse(args[2]));

                    Graph.MatrixGraph.SaveGraphMatrix(args[3], graphS);
                }
                if (args[0] == "solve")
                {
                    GradientDescentOptimizationMDC mdc = new GradientDescentOptimizationMDC();



                    mdc.Solve(args[1],int.Parse(args[2]));

                    LinearProgrammingOptimizationMDC.Solve(args[1]);
                }
            }




        }
    }
}
